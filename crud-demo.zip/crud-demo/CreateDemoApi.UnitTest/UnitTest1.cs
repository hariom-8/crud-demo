using CreateDemoApi.Controllers;
using CreateDemoApi.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;

namespace CreateDemoApi.UnitTest
{
    public class UnitTest1
    {
        private readonly Mock<BlogDbContext> _context;
        private readonly Mock<ILogger<BlogController>> _logger;
        private readonly BlogController blogController;
        public UnitTest1()
        {
            var options = new DbContextOptionsBuilder<BlogDbContext>()
            .Options;

            _logger = new Mock<ILogger<BlogController>>();
            var mockDbContext = new Mock<BlogDbContext>(options);
            mockDbContext.Setup(x => x.Posts).Returns(GetMockDbSet());
            blogController = new BlogController(mockDbContext.Object, _logger.Object);
        }
        [Fact]
        public void Test1()
        {
            var result = blogController.GetPostsByAuthor(1);
        }

        private DbSet<Post> GetMockDbSet()
        {
            var data = new List<Post>
        {
            new Post { PostID = 1, Title = "Post 1" ,AuthorID = 1},
            new Post { PostID = 2, Title = "Post 2" }
        }.AsQueryable();

            var mockDbSet = new Mock<DbSet<Post>>();
            mockDbSet.As<IQueryable<Post>>().Setup(m => m.Provider).Returns(data.Provider);
            mockDbSet.As<IQueryable<Post>>().Setup(m => m.Expression).Returns(data.Expression);
            mockDbSet.As<IQueryable<Post>>().Setup(m => m.ElementType).Returns(data.ElementType);
            mockDbSet.As<IQueryable<Post>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());

            return mockDbSet.Object;
        }
    }
}